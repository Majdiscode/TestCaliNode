//
//  Path.swift
//  TestCaliNode
//
//  Created by Majd Iskandarani on 5/9/25.
//

import Foundation

struct Path{
    struct Firestore{
        static let profiles = "profiles"
    }
}
